/*
Proširiti zadatak najbilzi_nuli_vreme ispisom u sekundama i minutima.
*/

